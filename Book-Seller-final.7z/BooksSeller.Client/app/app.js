﻿(function () {
    "use strict";

    var app = angular.module("booksSeller",
                            ["common.services"]);

}());